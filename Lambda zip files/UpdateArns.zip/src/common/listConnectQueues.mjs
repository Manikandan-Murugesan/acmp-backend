const region = process.env.Region;
import { ConnectClient, ListQueuesCommand } from "@aws-sdk/client-connect";
//const client = new ConnectClient({ region: region });
   export async function listQueues(InstanceId,srcRegion,NextToken="") {
        const client = new ConnectClient({ region: srcRegion });
        let response = null;
        try {
            const input = { 
                InstanceId: InstanceId, 
                QueueTypes: ['STANDARD'],
            };
            if(!!NextToken) input.NextToken = NextToken;
            const command = new ListQueuesCommand(input);
            response = await client.send(command);
        } catch (error) {
            console.error(error);
            response = error;
        }
        return response;
};