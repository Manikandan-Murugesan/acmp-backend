const region = process.env.Region;
// const region2=process.env.Region2;
import { ConnectClient, ListContactFlowsCommand } from "@aws-sdk/client-connect";
//const client = new ConnectClient({ region: region });
    export async function listContactflows(InstanceId,srcRegion,ContactFlowTypes,NextToken="") {
        const client = new ConnectClient({ region: srcRegion });
        let response = null;
        try {
            const input = { 
                InstanceId: InstanceId, 
                ContactFlowTypes:[ 
                    ContactFlowTypes
                    ]
            };
            if(!!NextToken) input.NextToken = NextToken;
            const command = new ListContactFlowsCommand(input);
            response = await client.send(command);
        } catch (error) {
            console.error(error)
        }
        return response;
};