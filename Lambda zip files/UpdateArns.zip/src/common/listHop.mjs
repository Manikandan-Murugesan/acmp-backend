const region = process.env.Region;
const region2=process.env.Region2;

import { ListHoursOfOperationsCommand, ConnectClient } from "@aws-sdk/client-connect";
export async function listHop  (srcInstanceId,srcRegion, condition = false){
    const client = new ConnectClient({ region: srcRegion });
    let MasterHopList = [];
    do {
        const input = {
            "InstanceId": srcInstanceId,
            ...(condition && { NextToken })
        };
        const command = new ListHoursOfOperationsCommand(input);
        const { HoursOfOperationSummaryList, NextToken } = await client.send(command);
        condition = !!NextToken;
        MasterHopList = [...MasterHopList, ...HoursOfOperationSummaryList];
    } while (condition);
    console.log(JSON.stringify({MasterHopList}));
    return MasterHopList;
};