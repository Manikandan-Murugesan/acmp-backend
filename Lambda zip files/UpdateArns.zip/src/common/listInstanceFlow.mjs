const region = process.env.Region;

const { ConnectClient, ListInstancesCommand } = require("@aws-sdk/client-connect");
const client = new ConnectClient({ region: region });

const listInstanceFlow = {
    async listInstanceFlow(NextToken="") {
        try {
            let response = null;
            const input = { 
            };
            if(!!NextToken) input.NextToken = NextToken;

            const command = new ListInstancesCommand(input);
            response = await client.send(command);
        } catch (error) {
            console.error(error)
        }
        return response;
    }
}
module.exports = listInstanceFlow;