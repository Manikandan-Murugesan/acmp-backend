const region = process.env.Region;
import { ListQuickConnectsCommand, ConnectClient } from "@aws-sdk/client-connect";

export async function listQCOp  (instanceId, QuickConnectTypes,srcRegion) {
    const client = new ConnectClient({ region: srcRegion });
        const input = {
            "InstanceId": instanceId,
            "QuickConnectTypes":[QuickConnectTypes],
        };
        const command = new ListQuickConnectsCommand(input);
        const resp = await client.send(command);
    console.log(JSON.stringify({resp}));
    return resp;
};
