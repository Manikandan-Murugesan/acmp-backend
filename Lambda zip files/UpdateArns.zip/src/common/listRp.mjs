const region = process.env.Region;

import { ListRoutingProfilesCommand, ConnectClient } from "@aws-sdk/client-connect";

export async function listRPOp(InstanceId,srcRegion,NextToken="") {
    let  condition = false;
    const client = new ConnectClient({ region: srcRegion });
    let MasterRpList = [];
    do {
        const input = {
            "InstanceId": InstanceId,
            ...(condition && { NextToken })
        };
       const command = new ListRoutingProfilesCommand(input);
        const { RoutingProfileSummaryList, NextToken } = await client.send(command);
        condition = !!NextToken;
        MasterRpList = [...MasterRpList, ...RoutingProfileSummaryList];
    } while (condition);
    console.log(JSON.stringify({MasterRpList}));
    return MasterRpList;
};
