console.log("Inside put item")
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";

const delay = ms => new Promise(resolve => setTimeout(resolve, ms))
//const region2=process.env.Region2;
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
const client = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(client);
    export async function putItemsinDDB (tableName, item) {
        // await delay(500)
          const resp = await ddbDocClient.send(
                new PutCommand({
                    TableName:tableName,
                    Item:item
                })
            );
            console.log(resp)
            return resp
};