const corSetting = require('./common/constants');
const { describeModule } = require('./common/describeModule.js');

const BucketName = process.env.BucketName;

exports.describeContactModule = async function (event, context, callback) {
    console.log(JSON.stringify({ event }))
    if (event.httpMethod !== 'GET') {
        throw new Error(`getMethod only accepts GET method, you tried: ${event.httpMethod} method.`);
    }
    const body = JSON.parse(event.body);
    const instaceid = body.instanceId;
    //check this
    const ContactFlowModuleId = body.ContactFlowModuleId;

    const flowOutput = await describeModule(instaceid, ContactFlowModuleId)


    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(flowOutput)
    };
    callback(null, response);
}