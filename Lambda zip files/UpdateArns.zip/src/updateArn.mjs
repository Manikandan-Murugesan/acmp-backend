import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { ScanCommand, BatchWriteCommand } from '@aws-sdk/lib-dynamodb';

// Initialize DynamoDB client
const client = new DynamoDBClient();


import { listConnectPrompts } from "./common/listConnectPrompts.mjs";
import { listQueues } from "./common/listConnectQueues.mjs";
import { listContactflows } from "./common/listContactflow.mjs";
import { listContactModule } from "./common/listContactModule.mjs";
import { putItemsinDDB } from "./common/putItemsinDDB.mjs";
import { listHop } from "./common/listHop.mjs";
import { listRPOp } from "./common/listRp.mjs";
import { listQCOp } from "./common/listQc.mjs";

const getPromptList = async(instanceId,srcRegion) =>{
    let NextToken ="";
    let promptList = [];
    do {
       const Output = !!NextToken ? await listConnectPrompts(instanceId,srcRegion,NextToken): await listConnectPrompts(instanceId,srcRegion);
       promptList = [...promptList, ...Output.PromptSummaryList];
       NextToken=Output.NextToken;
    } while (NextToken);
    return promptList;
    
};
const getQueueList = async(instanceId,srcRegion) =>{
    let NextToken ="";
    let queueList = [];
    do {
       const Output = !!NextToken ? await listQueues(instanceId,srcRegion,NextToken): await listQueues(instanceId,srcRegion);
       queueList = [...queueList, ...Output.QueueSummaryList];
       NextToken=Output.NextToken;
    } while (NextToken);
    return queueList;
};
const getContactflowList = async(instanceid,srcRegion) =>{
    let flowOutputList = [];
    const cfType = [
    'CONTACT_FLOW' , 'CUSTOMER_QUEUE' , 'CUSTOMER_HOLD' , 'CUSTOMER_WHISPER' , 'AGENT_HOLD' , 'AGENT_WHISPER' , 'OUTBOUND_WHISPER' , 'AGENT_TRANSFER' , 'QUEUE_TRANSFER'
  ];
    for(let type in cfType) {
        let NextToken ="";
        do {
           const flowOutput = !!NextToken ? await listContactflows(instanceid,srcRegion,cfType[type],NextToken): await listContactflows(instanceid,srcRegion,cfType[type]);
           flowOutputList = [...flowOutputList, ...flowOutput.ContactFlowSummaryList];
           NextToken=flowOutput.NextToken;
        } while (NextToken);
    }
    return flowOutputList;
};
const getQuickConnectList = async(instanceid,srcRegion) =>{
    let flowOutputList = [];
    const qcType = ['USER' , 'QUEUE' , 'PHONE_NUMBER'];
    for(let type in qcType) {
        let NextToken ="";
        do {
           const qcOutput = !!NextToken ? await listQCOp(instanceid,qcType[type],srcRegion,NextToken): await listQCOp(instanceid,qcType[type],srcRegion);
           flowOutputList = [...flowOutputList, ...qcOutput.QuickConnectSummaryList];
           NextToken=qcOutput.NextToken;
        } while (NextToken);
    }
    return flowOutputList;
};
const getContactFlowMouduleList = async(instanceid,srcRegion) => {
    let NextToken ="";
    let moduleOutputList = [];
    do {
       const moduleOutput = !!NextToken ? await listContactModule(instanceid,srcRegion,NextToken,): await listContactModule(instanceid,srcRegion);
       moduleOutputList = [...moduleOutputList, ...moduleOutput.ContactFlowModulesSummaryList];
       NextToken=moduleOutput.NextToken;
    } while (NextToken);
    return moduleOutputList;
    
};

async function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

export const deleteAllItems = async (tableName) => {
    let lastEvaluatedKey = null;

    do {
        const scanParams = {
            TableName: tableName
        };

        try {
            const scanResult = await client.send(new ScanCommand(scanParams));
            console.log("ScanResult", scanResult)
            const items = scanResult.Items;
            console.log("Scan items", items)
            lastEvaluatedKey = scanResult.id;

            if (items && items.length > 0) {
                await batchDeleteItems(tableName, items);
                console.log(`Deleted ${items.length} items from ${tableName}`);
            }

        } catch (error) {
            console.error(`Error scanning table ${tableName}:`, error);
            throw new Error('Error scanning table');
        }
    } while (lastEvaluatedKey);
};

const batchDeleteItems = async (tableName, items) => {
    const BATCH_SIZE = 25;
    const batches = [];

    for (let i = 0; i < items.length; i += BATCH_SIZE) {
        const batch = items.slice(i, i + BATCH_SIZE).map(item => ({
            DeleteRequest: {
                Key: { id: item.id },
            },
        }));
        batches.push(batch);
    }

    for (const batch of batches) {
        const params = {
            RequestItems: {
                [tableName]: batch,
            },
        };

        try {
            const response = await client.send(new BatchWriteCommand(params));

            // Handle unprocessed items
            if (response.UnprocessedItems && Object.keys(response.UnprocessedItems).length > 0) {
                console.log('Unprocessed items:', response.UnprocessedItems);
                // Optionally, retry unprocessed items here
            }
        } catch (error) {
            console.error('Error deleting batch:', error);
            throw new Error('Error deleting items in batch');
        }
    }
};

export const updateArn = async function (event, context) {
    console.log("Event",event)
    // var dbTableName=process.env.AssetInstanceTable
    // var events=JSON.parse(event)
    const instanceId = event.instanceId; // req body and region 
    console.log("ISID",instanceId)
        const srcRegion = event.srcRegion;
    // const tableName=dbTableName; // take from env vars
    var tablenames=process.env[`instance_${instanceId.replaceAll("-", "")}`]
    console.log("Names",tablenames)
    
    deleteAllItems(tablenames)
    .then(() => console.log('All items deleted successfully'))
    .catch(error => console.error('Error:', error));
    
    
    let PromptsList = await getPromptList(instanceId,srcRegion);
    let QueuesList = await getQueueList(instanceId,srcRegion);
    let ContactFlowList = await getContactflowList(instanceId,srcRegion);
    let ContactFlowModuleList = await getContactFlowMouduleList(instanceId,srcRegion);
    let HoursOfOperationList = await listHop(instanceId,srcRegion);
    let RoutingProfileList = await listRPOp(instanceId,srcRegion);
    let QuickConnectList = await getQuickConnectList(instanceId,srcRegion);
    console.log(JSON.stringify({PromptsList, QueuesList, ContactFlowList, ContactFlowModuleList, HoursOfOperationList, RoutingProfileList, QuickConnectList }));
    const masterList = [...PromptsList, ...ContactFlowList, ...ContactFlowModuleList,  ...QueuesList, ...HoursOfOperationList, ...RoutingProfileList, ...QuickConnectList];
    for(let item in masterList) {
        console.log(masterList[item]);
        await putItemsinDDB(tablenames, masterList[item]);
        await sleep(200);
    }
    console.log("completed all the actions",{
        "No. of Prompts": PromptsList.length,
        "No. of Contact Flows": ContactFlowList.length,
        "No. of Modules": ContactFlowModuleList.length,
        "No. of Queues": QueuesList.length,
        "No. of HOP": HoursOfOperationList.length,
        "No. of RPs": RoutingProfileList.length,
        "No. of Qs": QuickConnectList.length,
        "No. of Items pushed to DDB": masterList.length
        
    });
    return {
        "No. of Prompts": PromptsList.length,
        "No. of Contact Flows": ContactFlowList.length,
        "No. of Modules": ContactFlowModuleList.length,
        "No. of Queues": QueuesList.length,
        "No. of HOP": HoursOfOperationList.length,
        "No. of RPs": RoutingProfileList.length,
        "No. of Qs": QuickConnectList.length,
        "No. of Items pushed to DDB": masterList.length
        
    };
};