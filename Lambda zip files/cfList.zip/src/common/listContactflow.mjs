const region = process.env.Region;
// const region2=process.env.Region2;
import { ConnectClient, ListContactFlowsCommand } from "@aws-sdk/client-connect";
//const client = new ConnectClient({ region: region });
//r
export async function listContactflows(InstanceId,srcRegion,ContactFlowTypes,NextToken="") {
    console.log("Inside list contact flow")
        const client = new ConnectClient({ region: srcRegion });
        let response = null;
        try {
            const input = { 
                InstanceId: InstanceId, 
                ContactFlowTypes:[ 
                    ContactFlowTypes
                    ]
            };
            if(!!NextToken) input.NextToken = NextToken;
            const command = new ListContactFlowsCommand(input);
            response = await client.send(command);
            console.log("Response",response)
        } catch (error) {
            console.error(error)
        }
        return response;
    };