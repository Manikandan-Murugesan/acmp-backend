const region = process.env.AWS_REGION;

import { ConnectClient, ListContactFlowModulesCommand  } from "@aws-sdk/client-connect";
//const { ConnectClient, ListContactFlowModulesCommand  } = require("@aws-sdk/client-connect");


export async function listContactModule (InstanceId,cfType,srcRegion,NextToken="") {
        const client = new ConnectClient({ region: srcRegion });
        try {
            var response = null;
            const input = { 
                InstanceId: InstanceId,
                ContactFlowModuleState:cfType
            };
            console.log("Input",input)
            if(!!NextToken) input.NextToken = NextToken;
            const command = new ListContactFlowModulesCommand(input);
            response = await client.send(command);
        } catch (error) {
            console.error(error)
        }
        return response;
}