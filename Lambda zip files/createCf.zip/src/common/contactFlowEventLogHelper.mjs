// importing aws sdk issue
// import AWS from "@aws-sdk";
// const docClient = new AWS.DynamoDB.DocumentClient({
//     apiVersion: '2012-08-10',
//     sslEnabled: false,
//     paramValidation: false,
//     convertResponseTypes: false
// });
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient,PutCommand } from "@aws-sdk/lib-dynamodb";

 const client = new DynamoDBClient({});
 const ddbDocClient=DynamoDBDocumentClient.from(client)
 const tableName = process.env.EventTable;

// import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
// const client = new DynamoDBClient({});
export const contactFlowEventLogHelper = {
    async saveData(requestId, instanceid, userId, contactflowoutputName, s3ObjectPath, operation, sourceInstanceId, destinationinstanceId) {

        switch (operation) {
            case 'IMPORT':
                console.log("Inside Import")
                var inputTextToDB = '{"requestId": "' + requestId +
                    '","userId": "' + userId +
                    '","InstanceId": "' + instanceid +
                    '","ContactFlowName": "' + contactflowoutputName +
                    '","s3ObjectPath": "' + s3ObjectPath +
                    '","operation": "' + operation +
                    '","timestampDate" : "' + new Date().toISOString() + '"}';
                break;
            case 'MIGRATE':
                var inputTextToDB = '{"requestId": "' + requestId +
                    '","userId": "' + userId +
                    '","sourceInstanceId": "' + sourceInstanceId +
                    '","destinationinstanceId": "' + destinationinstanceId +
                    '","operation": "' + operation +
                    '","timestampDate" : "' + new Date().toISOString() + '"}';
                break

        }

        var paramsIns = {
            TableName: tableName,
            Item: JSON.parse(inputTextToDB)
        };

        console.log('contactFlowEventLogHelper saveData paramsIns', paramsIns);
        const command = new PutCommand(paramsIns);
        const response = await client.send(command);
        //const response = await ddbDocClient.send(paramsIns).promise();
        console.log('contactFlowEventLogHelper saveData response', response);
        return response;
    },
    // async gets3PromptEventLog(contactId) {
    // 	var params = {
    // 		TableName : tableName,
    // 		KeyConditionExpression: "#contactId = :contactIds",
    // 		ExpressionAttributeNames:{
    // 			"#contactId": "contactId"
    // 		},
    // 		ExpressionAttributeValues: {
    // 			":contactId": contactId
    // 		}
    // 	};

    // 	var output = await docClient.query(params).promise();
    // 	return output;
    // },
    // async scans3PromptEventLog() {
    //     const params = {
    //         TableName: tableName,
    //     };

    //     let scanResults = [];
    //     let items;

    // 	items = await docClient.scan(params).promise();
    //     items.Items.forEach((item) => scanResults.push(item));

    //     console.info('scanResults:', scanResults);
    //     return scanResults;
    // }
}
