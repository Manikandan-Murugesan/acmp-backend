import { ConnectClient, CreateContactFlowCommand } from "@aws-sdk/client-connect"; // ES Modules import
import corSetting from './common/constants.js';
import { contactFlowEventLogHelper } from './common/contactFlowEventLogHelper.js';
import { getUserId } from "./common/cognitoTokenParser.mjs";
const region = process.env.AWS_REGION;
const BucketName = process.env.BucketName;

export const createContactFlowModule = async (event, context, callback) => {
    console.log(JSON.stringify({ event }));
    
    if (event.httpMethod !== 'PUT') {
        throw new Error(`This function only accepts PUT method, you tried: ${event.httpMethod}.`);
    }

const client = new ConnectClient({ region: region });

    const body = JSON.parse(event.body);
    const instanceId = body.instanceId;
    const name = body.cName;
    const cfType = body.cfType;
    let fileContent = event.isBase64Encoded 
        ? Buffer.from(event.body, 'base64').toString().split('\r\n')[4].trim() 
        : event.body.split('\r\n')[4].trim();

    const input = {
        InstanceId: instanceId,
        Name: name,
        Content: fileContent,
    };

    const command = new CreateContactFlowCommand(input);
    const flowOutput = await client.send(command);
    const username = getUserId(event.headers.Authorization);

    if (flowOutput) {
        const requestId = `${username}_${Date.now()}`;
        await contactFlowEventLogHelper.saveData(requestId, username, 'UPLOAD');
    }

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(flowOutput)
    };

    callback(null, response);
};
