const region = process.env.AWS_REGION;

import { ConnectClient, UpdateContactFlowModuleContentCommand ,CreateContactFlowModuleCommand } from "@aws-sdk/client-connect";
const client = new ConnectClient({ region: region });

    export async function updateContactModule (input) {
        console.log("Inside create module", input)
        let flowOutput;
        const command = new UpdateContactFlowModuleContentCommand(input);
        try {
            console.log("Inside try", command)
            flowOutput = await client.send(command); 
        } catch (error) {
            flowOutput = error
        }
        console.log("flowOutput", flowOutput)
        return flowOutput;
    }
  export async function createContactModule (input) {
        console.log("Inside create flow")
        let flowOutput
        const command = new CreateContactFlowModuleCommand(input);
          try {
            console.log("Inside try", command)
           flowOutput = await client.send(command); 
          } catch (error) {
            flowOutput = error
        }
        console.log("Flow ouput",flowOutput)
        return flowOutput;
    }


