const region = process.env.AWS_REGION;

const { ConnectClient, UpdateContactFlowModuleContentCommand } = require( "@aws-sdk/client-connect");
const client = new ConnectClient({ region: region });

const createModule = {
    async createModule (input) {
        const command = new UpdateContactFlowModuleContentCommand(input);
        const flowOutput = await client.send(command); 
        return flowOutput;
    }
};

module.exports = createModule;