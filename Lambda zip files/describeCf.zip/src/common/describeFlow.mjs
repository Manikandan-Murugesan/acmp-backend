const region = process.env.AWS_REGION;

import { ConnectClient, DescribeContactFlowCommand } from "@aws-sdk/client-connect";
const client = new ConnectClient({ region: region });

export async function describeFlow(InstanceId, ContactFlowId) {
        try {
            var response = null;
            const input = { 
                InstanceId: InstanceId, 
                ContactFlowId: ContactFlowId
                
            };
            console.log("Input--",input)
            const command = new DescribeContactFlowCommand (input);
            console.log("Command",)
            response = await client.send(command);
        } catch (error) {
            console.error(error)
        }
        return response;
}
