const region = process.env.AWS_REGION;

import { ConnectClient, DescribeContactFlowModuleCommand } from "@aws-sdk/client-connect";
const client = new ConnectClient({ region: region });

export async function describeModule(InstanceId, ContactFlowModuleId) {
        try {
            var response = null;
            const input = { 
                InstanceId: InstanceId, 
                ContactFlowModuleId: ContactFlowModuleId
                
            };
            console.log("Input--",input)
            const command = new DescribeContactFlowModuleCommand (input);
            response = await client.send(command);
        } catch (error) {
            console.error(error)
        }
        return response;
    
}
