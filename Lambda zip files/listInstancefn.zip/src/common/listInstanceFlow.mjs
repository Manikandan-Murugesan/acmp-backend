const region = process.env.AWS_REGION;

import { ConnectClient, ListInstancesCommand } from "@aws-sdk/client-connect";
const client = new ConnectClient({ region: region });

export async function listInstanceFlow(NextToken="") {
        try {
            console.log("Inside the list instance function")
            var response = null;
            const input = { 
            };
            if(!!NextToken) input.NextToken = NextToken;
            
            console.log("Input--",input)
            
            const command = new ListInstancesCommand(input);
            console.log("Command--",command)
            response = await client.send(command);
            console.log("response",response)
        } catch (error) {
            console.error(error)
        }
        return response;
    
}
