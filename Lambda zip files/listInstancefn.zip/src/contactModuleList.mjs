const { ConnectClient, CreateContactFlowCommand } = require( "@aws-sdk/client-connect");// ES Modules import
const corSetting = require('./common/constants');
const { contactFlowEventLogHelper } = require('./common/contactFlowEventLogHelper.js');



exports.contactModuleList = async function (event, context, callback) {
    console.log(JSON.stringify({ event }))
    if (event.httpMethod !== 'POST') {
        throw new Error(`createcontactFlow only accepts post method, you tried: ${event.httpMethod} method.`);
    }
   
    const body = JSON.parse(event.body);
    const instaceid = body.instanceId;
    const name = body.cName;
    const cfType = body.cfType;
    let fileContent = event.isBase64Encoded ? Buffer.from(event.body, 'base64').split('\r\n')[4].trim() : event.body.split('\r\n')[4].trim();

    const input = { // CreateContactFlowRequest
        InstanceId: instaceid, // required
        Name: name, // required
        Type: cfType,// required
        Content: fileContent, // required        
      };

      const command = new CreateContactFlowCommand(input);
      const flowOutput = await client.send(command);    
    
      if(flowOutput){
        var requestId = username + "_"+ Date.now();
        await contactFlowEventLogHelper.saveData(requestId, username, 'UPLOAD') ;
    }
      
    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(flowOutput)
    };
    callback(null, response);
}