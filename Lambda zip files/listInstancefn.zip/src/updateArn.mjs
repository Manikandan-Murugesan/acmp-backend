import { ConnectClient, CreateContactFlowCommand } from "@aws-sdk/client-connect"; // ES Modules import
const corSetting = require('./common/constants');

const { contactFlowEventLogHelper } = require('./common/contactFlowEventLogHelper.js');

const BucketName = process.env.BucketName;

exports.updateArn = async function (event, context, callback) {
    console.log(JSON.stringify({ event }))
    if (event.httpMethod !== 'PUT') {
        throw new Error(`put only accepts put method, you tried: ${event.httpMethod} method.`);
    }



const client = new ConnectClient(config);

const body = JSON.parse(event.body);
const instaceid = body.instanceId;
const name = body.cName;
const cfType = body.cfType;
let fileContent = event.isBase64Encoded ? Buffer.from(event.body, 'base64').split('\r\n')[4].trim() : event.body.split('\r\n')[4].trim();


const input = { // CreateContactFlowModuleRequest
  InstanceId: instaceid, // required
  Name: name, // required
  Content: fileContent, // required
  
};
const command = new CreateContactFlowModuleCommand(input);
const flowOutput = await client.send(command);

if(flowOutput){
    var requestId = username + "_"+ Date.now();
    await contactFlowEventLogHelper.saveData(requestId, username, 'UPLOAD') ;
}

const response = {
    statusCode: 200,
    headers: corSetting,
    body: JSON.stringify(flowOutput)
};
callback(null, response);
// { // CreateContactFlowModuleResponse
//   Id: "STRING_VALUE",
//   Arn: "STRING_VALUE",
// };

};