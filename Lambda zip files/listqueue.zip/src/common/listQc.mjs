import { ListQuickConnectsCommand, ConnectClient } from "@aws-sdk/client-connect";

export const listQCOp = async (parsedBody) => {
    let  condition = false;
    const client = new ConnectClient({ region: parsedBody.srcRegion });
    let MasterQcList = [];
    do {
        const input = {
            "InstanceId": parsedBody.srcInstanceId,
            "QuickConnectTypes":[parsedBody.QuickConnectTypes],
            ...(condition && { NextToken })
        };
        const command = new ListQuickConnectsCommand(input);
        const { QuickConnectSummaryList, NextToken } = await client.send(command);
        condition = !!NextToken;
        MasterQcList = [...MasterQcList, ...QuickConnectSummaryList];
    } while (condition);
    console.log(JSON.stringify({MasterQcList}));
    return MasterQcList;
};