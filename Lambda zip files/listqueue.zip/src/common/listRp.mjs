import { ListRoutingProfilesCommand, ConnectClient } from "@aws-sdk/client-connect";

export const listRPOp = async (parsedBody) => {
    let  condition = false;
    const client = new ConnectClient({ region: parsedBody.srcRegion });
    let MasterRpList = [];
    do {
        const input = {
            "InstanceId": parsedBody.srcInstanceId,
            ...(condition && { NextToken })
        };
        const command = new ListRoutingProfilesCommand(input);
        const { RoutingProfileSummaryList, NextToken } = await client.send(command);
        condition = !!NextToken;
        MasterRpList = [...MasterRpList, ...RoutingProfileSummaryList];
    } while (condition);
    console.log(JSON.stringify({MasterRpList}));
    return MasterRpList;
};