import { corSetting } from './common/constants.mjs';
import { performMigrateHop } from './performMigrateHop.mjs';
import { performMigrateQueue } from './performMigrateQueue.mjs';
import { performMigrateRp } from './performMigrateRp.mjs';
import { performMigrateQc } from './performMigrateQc.mjs';
import { listQueueOp } from './common/listQueue.mjs';
import { listHopOp } from './common/listHop.mjs';
import { listRPOp } from './common/listRp.mjs';
import { listQCOp } from './common/listQc.mjs';

export const listQueue = async (event, context) => {
    console.log(JSON.stringify({ event }));

    const response = {
        headers: corSetting
    };

    if (event.httpMethod !== 'POST') {
        response.statusCode = 415;
        response.body = JSON.stringify({
            error: `Resource API only accepts POST method, you tried: ${event.httpMethod} method.`
        });
    } else {
        const parsedBody = JSON.parse(event.body);
        const command = parsedBody.command;

        console.log(JSON.stringify({ command }));

        switch (command) {
            case 'MIGRATE_HOP':
                const hopResult = await performMigrateHop(parsedBody);
                response.body = JSON.stringify({ result: hopResult });
                break;

            case 'MIGRATE_QUEUE':
                const queueResult = await performMigrateQueue(parsedBody);
                response.body = JSON.stringify({ result: queueResult });
                break;

            case 'MIGRATE_ROUTINGPROFILE':
                const rpResult = await performMigrateRp(parsedBody);
                response.body = JSON.stringify({ result: rpResult });
                break;

            case 'MIGRATE_QUICKCONNECTS':
                const qcResult = await performMigrateQc(parsedBody);
                response.body = JSON.stringify({ result: qcResult });
                break;

            case 'ListQueue':
                console.log('Inside list queue', parsedBody);
                parsedBody.QueueTypes = 'STANDARD';
                const listQueueResult = await listQueueOp(parsedBody);
                response.body = JSON.stringify({ result: listQueueResult });
                break;

            case 'ListHop':
                console.log('Inside list hop', parsedBody);
                const listHopResult = await listHopOp(parsedBody);
                response.body = JSON.stringify({ result: listHopResult });
                break;

            case 'ListRP':
                console.log('Inside list RP', parsedBody);
                const listRPResult = await listRPOp(parsedBody);
                response.body = JSON.stringify({ result: listRPResult });
                break;

            case 'ListQC':
                console.log('Inside list QC', parsedBody);
                const listQCResult = await listQCOp(parsedBody);
                response.body = JSON.stringify({ result: listQCResult });
                break;

            default:
                response.statusCode = 422;
                response.body = JSON.stringify({
                    error: `The command: "${command}" is not valid.`
                });
                break;
        }
    }

    console.log(JSON.stringify({ response }));
    return response;
};
