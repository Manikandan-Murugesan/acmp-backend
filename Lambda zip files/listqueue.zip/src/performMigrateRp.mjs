import { describeRp } from './common/describeRp.mjs';
import { describeRpQueue } from './common/describeRpQueue.mjs';
import { scanItemFromDDB } from './common/scanArnTable.mjs';
import { createRp } from './common/createRp.mjs';
import { updateRpName } from './common/updateRpName.mjs';
import { getItemFromDDB } from './common/getItemFromDDB.mjs';
import { updateRpAgentAvailability } from './common/updateRpAgentAvailability.mjs';
import { updateRpConcurrency } from './common/updateRpConcurrency.mjs';
import { updateRpDefaultOutboundQueue } from './common/updateRpDefaultOutboundQueue.mjs';

export const getDestOutboundQueueId = async (srcInstanceId, destInstanceId, DefaultOutboundQueueId, srcRegion, destRegion) => {
    const returnObject = {};
    console.log("Input for get dest output", DefaultOutboundQueueId);

    const srcOutboundIdDetails = await getItemFromDDB(DefaultOutboundQueueId, process.env[`instance_${srcInstanceId.replace(/-/g, "")}`], srcRegion);
    console.log("Inside new function",srcOutboundIdDetails);
    const srcQueueName = srcOutboundIdDetails['Item']['Name'];

    const filterExpression = `#HOPN = :HOPN`;
    const expressionAttributeNames = { '#HOPN': 'Name' };
    const expressionAttributeValues = { ':HOPN': srcQueueName };

    const destQueueDetails = await scanItemFromDDB(
        process.env[`instance_${destInstanceId.replace(/-/g, "")}`], 
        filterExpression, expressionAttributeNames, expressionAttributeValues, destRegion
    );
    console.log("after table query", destQueueDetails)

    if (destQueueDetails.Count === 1) {
        returnObject.statusCode = '200';
        returnObject.value = destQueueDetails.Items[0].Id;
        returnObject.error = false;
    } else {
        returnObject.statusCode = '201';
        returnObject.error = true;
        returnObject.reason = `The Outbound queue ${srcQueueName} is not available in ${destInstanceId}`;
    }

    return returnObject;
};

export const getDestQueueConfigId = async (srcInstanceId, destInstanceId, QueueId, srcRegion, destRegion) => {
    const returnObject = {};
    console.log("Input for get dest Queue Config", QueueId);

    const srcQueueDetails = await getItemFromDDB(QueueId, process.env[`instance_${srcInstanceId.replace(/-/g, "")}`], srcRegion);
    console.log("Inside new function", srcQueueDetails);
    const srcQueueName = srcQueueDetails['Item']['Name'];

    const filterExpression = `#HOPN = :HOPN`;
    const expressionAttributeNames = { '#HOPN': 'Name' };
    const expressionAttributeValues = { ':HOPN': srcQueueName };

    const destQueueDetails = await scanItemFromDDB(
        process.env[`instance_${destInstanceId.replace(/-/g, "")}`], 
        filterExpression, expressionAttributeNames, expressionAttributeValues, destRegion
    );
    console.log("after table query", destQueueDetails)

    if (destQueueDetails.Count === 1) {
        returnObject.value = destQueueDetails.Items[0].Id;
        returnObject.error = false;
    } else {
        returnObject.error = true;
        returnObject.reason = `The queue ${srcQueueName} is not available in ${destInstanceId}`;
    }
    console.log("return object", returnObject);
    return returnObject;
};

export const performMigrateRp = async (parsedBody) => {
    const migrationResultArray = [];
    const detailedSrcList = [];

    for (let rpListItem of parsedBody.selectedItem) {
        const rpDescription = await describeRp(parsedBody.srcRegion, parsedBody.srcInstanceId, rpListItem);
        const rpQueueDescription = await describeRpQueue(parsedBody.srcRegion, parsedBody.srcInstanceId, rpListItem);

        rpListItem = { ...rpDescription, rpQueueDescription };
        detailedSrcList.push(rpListItem);
    }
console.log("detailedSrcList", detailedSrcList);
    for (let rpItem of detailedSrcList) {
        console.log("rpItem", rpItem);
        const tableName = process.env[`instance_${parsedBody.destInstanceId.replace(/-/g, "")}`];
        const filterExpression = `#RPN = :RPV`;
        const expressionAttributeNames = { '#RPN': 'Name' };
        const expressionAttributeValues = { ':RPV': rpItem.Name };

        const rpAvailable = await scanItemFromDDB(tableName, filterExpression, expressionAttributeNames, expressionAttributeValues);
        console.log("rpAvailable", rpAvailable);
        const responses = {};

        if (rpAvailable.Count > 0) {
            console.log("Update logic")
            try {
                const destOutboundQueueId = await getDestOutboundQueueId(parsedBody.srcInstanceId, parsedBody.destInstanceId, rpItem.DefaultOutboundQueueId, parsedBody.srcRegion, parsedBody.destRegion);
                console.log("destOutboundQueueId", destOutboundQueueId);
                if (destOutboundQueueId.error) throw destOutboundQueueId;

                const agentAvailabilityInput = {
                    InstanceId: parsedBody.destInstanceId,
                    RoutingProfileId: rpAvailable.Items[0].Id,
                    Name: rpItem.Name,
                    AgentAvailabilityTimer: rpItem.AgentAvailabilityTimer
                };

                let resp = await updateRpAgentAvailability(parsedBody.destRegion, agentAvailabilityInput);
                responses.name = agentAvailabilityInput.Name;
                responses.statusCode = resp['$metadata'].httpStatusCode == 200 ? '200' : '201';

                const concurrencyInput = {
                    InstanceId: parsedBody.destInstanceId,
                    RoutingProfileId: rpAvailable.Items[0].Id,
                    MediaConcurrencies: rpItem.MediaConcurrencies
                };

                let resp1 = await updateRpConcurrency(parsedBody.destRegion, concurrencyInput);
                responses.statusCode = resp1['$metadata'].httpStatusCode == 200 ? '200' : '201';

                const outboundQueueInput = {
                    InstanceId: parsedBody.destInstanceId,
                    RoutingProfileId: rpAvailable.Items[0].Id,
                    DefaultOutboundQueueId: destOutboundQueueId.value,
                };

                let resp2 = await updateRpDefaultOutboundQueue(parsedBody.destRegion, outboundQueueInput);
                responses.statusCode = resp2['$metadata'].httpStatusCode == 200 ? '200' : '201';

                const nameInput = {
                    InstanceId: parsedBody.destInstanceId,
                    RoutingProfileId: rpAvailable.Items[0].Id,
                    Name: rpItem.Name,
                    Description: rpItem.Description || rpItem.Name,
                };

                let resp3 = await updateRpName(parsedBody.destRegion, nameInput);
                responses.statusCode = resp3['$metadata'].httpStatusCode == 200 ? '200' : '201';

                migrationResultArray.push(responses);
            } catch (error) {
                responses.statusCode = '201';
                responses.error = true;
                responses.Name = rpItem.Name;
                responses.reason = `${error.name}: ${error.message}. Error while updating RP`;
                migrationResultArray.push(responses);
            }
        } else {
            console.log("Create logic")
            try {
                const destOutboundQueueId = await getDestOutboundQueueId(parsedBody.srcInstanceId, parsedBody.destInstanceId, rpItem.DefaultOutboundQueueId, parsedBody.srcRegion, parsedBody.destRegion);
                console.log("destOutboundQueueId", destOutboundQueueId);
                if (destOutboundQueueId.error) throw destOutboundQueueId;

                let newQueueConfig = [];

                for (let configItem of rpItem.rpQueueDescription) {
                    const destQueueConfigId = await getDestQueueConfigId(parsedBody.srcInstanceId, parsedBody.destInstanceId, configItem.QueueId, parsedBody.srcRegion, parsedBody.destRegion);
                    if (destQueueConfigId.error) throw destQueueConfigId;

                    newQueueConfig.push({
                        QueueReference: {
                            QueueId: destQueueConfigId.value,
                            Channel: configItem.Channel
                        },
                        Priority: configItem.Priority,
                        Delay: configItem.Delay
                    });
                }

                const createApiInput = {
                    InstanceId: parsedBody.destInstanceId,
                    Name: rpItem.Name,
                    Description: rpItem.Description || rpItem.Name,
                    DefaultOutboundQueueId: destOutboundQueueId.value,
                    MediaConcurrencies: rpItem.MediaConcurrencies,
                    QueueConfigs: newQueueConfig,
                    Tags: rpItem.Tags,
                };
                console.log("createApiInput", createApiInput);

                let resp = await createRp(parsedBody.destRegion, createApiInput);
                console.log("resp", resp);
                responses.statusCode = resp['$metadata'].httpStatusCode == 200 ? '200' : '404';
                responses.error = resp['$metadata'].httpStatusCode != 200;
                responses.name = createApiInput.Name;

                migrationResultArray.push(responses);
            } catch (error) {
                console.info(error);
                responses.statusCode = '404';
                responses.error = true;
                responses.reason = `${rpItem.Name}: Error while creating new Routing Profile. ${error.reason}`;
                migrationResultArray.push(responses);
            }
        }
    }
console.log("migrationResultArray", migrationResultArray);
    return migrationResultArray;
};
