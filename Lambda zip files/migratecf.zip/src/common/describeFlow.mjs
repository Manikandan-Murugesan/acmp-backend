const region = process.env.AWS_REGION;

import { ConnectClient, DescribeContactFlowCommand } from "@aws-sdk/client-connect";
//const client = new ConnectClient({ region: region });

    export async function describeFlow(InstanceId, ContactFlowId,desRegion) {
        const client = new ConnectClient({ region: desRegion });
        let response = null;
        try {
            const input = { 
                InstanceId: InstanceId, 
                ContactFlowId: ContactFlowId
                
            };
            const command = new DescribeContactFlowCommand (input);
            response = await client.send(command);
        } catch (error) {
            console.error(error);
        }
        return response;
};