import { DynamoDBDocumentClient, GetCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
const client = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(client);
    export async function getItemFromDDB (tableName, Id) {
        console.log({tableName, Id});
        const respo = await ddbDocClient.send(
            new GetCommand({
                TableName: tableName,
                Key: {"Id":Id} 
            })
        );
        console.log({respo});
        return respo;
};
