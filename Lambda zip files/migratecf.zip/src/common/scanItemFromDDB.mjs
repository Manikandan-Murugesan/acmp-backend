import { DynamoDBDocumentClient, ScanCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
const client = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(client);

    export async function scanItemFromDDB (tableName, filterExpression, expressionAttributeNames, expressionAttributeValues) {
        console.log({tableName, filterExpression, expressionAttributeNames, expressionAttributeValues});
        const resp = await ddbDocClient.send(
            new ScanCommand({
                TableName: tableName,
                FilterExpression: filterExpression,
                ExpressionAttributeNames: expressionAttributeNames,
                ExpressionAttributeValues: expressionAttributeValues
            })
        );
        console.log({resp});
        return resp;
};