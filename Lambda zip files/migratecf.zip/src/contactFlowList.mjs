const corSetting = require('./common/constants');
const { listContactflows } = require('./common/listContactflow.js');

const BucketName = process.env.BucketName;
//f
exports.contactFlowList = async function (event, context, callback) {
    console.log(JSON.stringify({ event }))
    if (event.httpMethod !== 'GET') {
        throw new Error(`getMethod only accepts GET method, you tried: ${event.httpMethod} method.`);
    }
    const body = JSON.parse(event.body);
    const instanceid = body.instanceId;
    const cfType = body.cfType;
    let NextToken =""
    //const flowOutput = await listContactflows(instanceid, cfType)

    let flowOutputList = []
    do {
        
       const flowOutput = !!NextToken ? await listContactflows(instanceid,cfType,NextToken): await listInstanceFlow(instanceid,cfType)
       flowOutputList = [...flowOutput.ContactFlowSummaryList]
       NextToken=flowOutput.NextToken
    } while (NextToken);

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(flowOutputList)
    };
    callback(null, response);
}