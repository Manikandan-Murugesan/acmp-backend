const corSetting = require('./common/constants');
const { describeFlow } = require('./common/describeFlow.js');

const BucketName = process.env.BucketName;
//r
exports.describeContactFlow = async function (event, context, callback) {
    console.log(JSON.stringify({ event }))
    if (event.httpMethod !== 'GET') {
        throw new Error(`getMethod only accepts GET method, you tried: ${event.httpMethod} method.`);
    }
    const body = JSON.parse(event.body);
    const instaceid = body.instanceId;
    const ContactFlowId = body.cfId;

    const flowOutput = await describeFlow(instaceid, ContactFlowId)

    

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(flowOutput)
    };
    callback(null, response);
}