const getUserId = (token) => {
    let usernameValue = '';
    try {
        const segments = token.split('.');
        if (segments.length !== 3) {
            throw new Error('Invalid token: Not enough or too many segments');
        }

        const payloadSeg = segments[1];
        const payload = JSON.parse(base64urlDecode(payloadSeg));
        usernameValue = payload['cognito:username'] || '';
    } catch (e) {
        console.error(`Error decoding token: ${e}`);
    }

    return usernameValue;
};

const base64urlDecode = (str) => {
    // Replace URL-safe characters
    str = str.replace(/-/g, '+').replace(/_/g, '/');
    // Pad the string to make it a valid base64 string
    const padding = str.length % 4;
    if (padding) {
        str += '='.repeat(4 - padding);
    }
    return Buffer.from(str, 'base64').toString('utf-8'); // Decode and return as string
};

export default {
    getUserId
};
