import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient,PutCommand } from "@aws-sdk/lib-dynamodb";

 const client = new DynamoDBClient({});
 const ddbDocClient=DynamoDBDocumentClient.from(client)
const tableName = process.env.EventTable;

const contactFlowEventLogHelper = {
    async saveData(requestId, instanceid, userId, contactflowoutputName, s3ObjectPath, operation, sourceInstanceId, destinationinstanceId) {
        console.log({ requestId, instanceid, userId, contactflowoutputName, s3ObjectPath, operation, sourceInstanceId, destinationinstanceId });
        let inputTextToDB;

        switch (operation) {
            case 'IMPORT':
                console.log("Inside Import");
                inputTextToDB = JSON.stringify({
                    requestId,
                    userId,
                    InstanceId: instanceid,
                    ContactFlowName: contactflowoutputName,
                    operation,
                    timestampDate: new Date().toISOString()
                });
                break;
            case 'MIGRATE':
                inputTextToDB = JSON.stringify({
                    requestId,
                    userId,
                    sourceInstanceId,
                    destinationinstanceId,
                    ContactFlowName: contactflowoutputName,
                    operation,
                    timestampDate: new Date().toISOString()
                });
                break;
        }

        const paramsIns = {
            TableName: tableName,
            Item: JSON.parse(inputTextToDB)
        };

        console.log('contactFlowEventLogHelper saveData paramsIns', paramsIns);
         const command = new PutCommand(paramsIns);
        const response = await client.send(command);
        console.log('contactFlowEventLogHelper saveData response', response);
        return response;
    }
};

export default contactFlowEventLogHelper;
