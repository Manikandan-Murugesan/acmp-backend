import { ConnectClient, UpdateContactFlowContentCommand, CreateContactFlowCommand } from "@aws-sdk/client-connect";

const region = process.env.AWS_REGION;
const client = new ConnectClient({ region });

const createContactFlow = {
    async updateContactFlow(input) {
        const command = new UpdateContactFlowContentCommand(input);
        const flowOutput = await client.send(command);
        return flowOutput;
    },
    async createContactFlow(input) {
        const command = new CreateContactFlowCommand(input);
        const flowOutput = await client.send(command);
        return flowOutput;
    }
};

export default createContactFlow;
