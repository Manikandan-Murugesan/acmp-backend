import { ConnectClient, DescribeContactFlowCommand } from "@aws-sdk/client-connect";

const region = process.env.AWS_REGION;
const client = new ConnectClient({ region });

const describeFlow = {
    async describeFlow(InstanceId, ContactFlowId) {
        let response = null;
        try {
            const input = { 
                InstanceId,
                ContactFlowId 
            };
            const command = new DescribeContactFlowCommand(input);
            response = await client.send(command);
        } catch (error) {
            console.error(error);
        }
        return response;
    }
};

export default describeFlow;
