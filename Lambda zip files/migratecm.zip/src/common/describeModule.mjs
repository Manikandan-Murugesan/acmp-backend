import { ConnectClient, DescribeContactFlowModuleCommand } from "@aws-sdk/client-connect";

export async function describeModule(InstanceId, ContactFlowModuleId, desRegion) {
        const client = new ConnectClient({ region: desRegion });
        let response = null;
        try {
            const input = {
                InstanceId,
                ContactFlowModuleId
            };
            const command = new DescribeContactFlowModuleCommand(input);
            response = await client.send(command);
        } catch (error) {
            console.error(error);
        }
        return response;
    }

