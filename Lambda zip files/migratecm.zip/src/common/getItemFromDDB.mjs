import { DynamoDBDocumentClient, GetCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";

const client = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(client);

export async function getItemFromDDB(tableName, Id) {
        console.log({ tableName, Id });
        const response = await ddbDocClient.send(
            new GetCommand({
                TableName: tableName,
                Key: { Id } 
            })
        );
        console.log({ response });
        return response;
    }
