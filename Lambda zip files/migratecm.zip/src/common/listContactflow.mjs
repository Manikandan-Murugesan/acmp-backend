import { ConnectClient, ListContactFlowsCommand } from "@aws-sdk/client-connect";

const region = process.env.AWS_REGION;
const client = new ConnectClient({ region });

const listContactflows = {
    async listContactflows(InstanceId, ContactFlowTypes, NextToken = "") {
        let response = null;
        try {
            const input = { 
                InstanceId,
                ContactFlowTypes: [ContactFlowTypes],
                ...(NextToken && { NextToken }) // Add NextToken only if it's provided
            };
            const command = new ListContactFlowsCommand(input);
            response = await client.send(command);
        } catch (error) {
            console.error(error);
        }
        return response;
    }
};

export default listContactflows;
