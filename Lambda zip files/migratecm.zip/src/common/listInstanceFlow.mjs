import { ConnectClient, ListInstancesCommand } from "@aws-sdk/client-connect";

const region = process.env.AWS_REGION;
const client = new ConnectClient({ region });

const listInstanceFlow = {
    async listInstanceFlow(NextToken = "") {
        try {
            const input = {
                ...(NextToken && { NextToken }) // Conditionally add NextToken
            };

            const command = new ListInstancesCommand(input);
            const response = await client.send(command);
            return response; // Return response here
        } catch (error) {
            console.error(error);
            return null; // Return null in case of an error
        }
    }
};

export default listInstanceFlow;
