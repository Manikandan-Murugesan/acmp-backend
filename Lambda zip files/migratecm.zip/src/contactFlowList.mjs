import corSetting from './common/constants.mjs';
import { listContactflows } from './common/listContactflow.mjs';

const BucketName = process.env.BucketName;

export const contactFlowList = async (event, context) => {
    console.log(JSON.stringify({ event }));

    if (event.httpMethod !== 'GET') {
        throw new Error(`getMethod only accepts GET method, you tried: ${event.httpMethod} method.`);
    }

    const body = JSON.parse(event.body);
    const instanceId = body.instanceId;
    const cfType = body.cfType;
    let NextToken = "";
    
    let flowOutputList = [];
    
    do {
        const flowOutput = !!NextToken 
            ? await listContactflows(instanceId, cfType, NextToken) 
            : await listContactflows(instanceId, cfType);
        
        flowOutputList = [...flowOutput.ContactFlowSummaryList];
        NextToken = flowOutput.NextToken;
    } while (NextToken);

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(flowOutputList)
    };

    return response;
};
