import { ConnectClient, CreateContactFlowCommand } from "@aws-sdk/client-connect"; // ES Modules import
import corSetting from './common/constants.mjs';
import { contactFlowEventLogHelper } from './common/contactFlowEventLogHelper.mjs';

export const contactModuleList = async (event, context) => {
    console.log(JSON.stringify({ event }));

    if (event.httpMethod !== 'POST') {
        throw new Error(`createcontactFlow only accepts POST method, you tried: ${event.httpMethod} method.`);
    }

    const body = JSON.parse(event.body);
    const instanceId = body.instanceId;
    const name = body.cName;
    const cfType = body.cfType;
    const fileContent = event.isBase64Encoded 
        ? Buffer.from(event.body, 'base64').toString().split('\r\n')[4].trim() 
        : event.body.split('\r\n')[4].trim();

    const input = { // CreateContactFlowRequest
        InstanceId: instanceId, // required
        Name: name, // required
        Type: cfType, // required
        Content: fileContent, // required        
    };

    const command = new CreateContactFlowCommand(input);
    const flowOutput = await client.send(command);    
    
    if (flowOutput) {
        const requestId = `${username}_${Date.now()}`;
        await contactFlowEventLogHelper.saveData(requestId, username, 'UPLOAD');
    }

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(flowOutput)
    };

    return response; // Directly returning the response instead of using a callback
};
