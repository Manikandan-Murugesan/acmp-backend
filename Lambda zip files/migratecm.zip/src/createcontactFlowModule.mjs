import { ConnectClient, CreateContactFlowModuleCommand } from "@aws-sdk/client-connect"; // ES Modules import
import corSetting from './common/constants.mjs';
import { contactFlowEventLogHelper } from './common/contactFlowEventLogHelper.mjs';

const BucketName = process.env.BucketName;

export const createContactFlowModule = async (event, context) => {
    console.log(JSON.stringify({ event }));

    if (event.httpMethod !== 'PUT') {
        throw new Error(`PUT only accepts PUT method, you tried: ${event.httpMethod} method.`);
    }

    const client = new ConnectClient({ region: process.env.AWS_REGION }); // Ensure to set the region in the config

    const body = JSON.parse(event.body);
    const instanceId = body.instanceId;
    const name = body.cName;
    const cfType = body.cfType;
    const fileContent = event.isBase64Encoded 
        ? Buffer.from(event.body, 'base64').toString().split('\r\n')[4].trim() 
        : event.body.split('\r\n')[4].trim();

    const input = { // CreateContactFlowModuleRequest
        InstanceId: instanceId, // required
        Name: name, // required
        Content: fileContent, // required
    };

    const command = new CreateContactFlowModuleCommand(input);
    
    let flowOutput;
    try {
        flowOutput = await client.send(command);
    } catch (error) {
        console.error("Error creating contact flow module:", error);
        throw new Error("Failed to create contact flow module");
    }

    if (flowOutput) {
        const requestId = `${username}_${Date.now()}`;
        await contactFlowEventLogHelper.saveData(requestId, username, 'UPLOAD');
    }

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(flowOutput),
    };

    return response; // Directly return the response instead of using a callback
};
