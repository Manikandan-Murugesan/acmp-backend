import corSetting from './common/constants.mjs';
import { describeFlow } from './common/describeFlow.mjs';

const BucketName = process.env.BucketName;

export const describeContactFlow = async (event) => {
    console.log(JSON.stringify({ event }));

    if (event.httpMethod !== 'GET') {
        throw new Error(`GET method only accepts GET method, you tried: ${event.httpMethod} method.`);
    }

    const body = JSON.parse(event.body);
    const instanceId = body.instanceId; // Corrected spelling
    const contactFlowId = body.cfId; // Use camelCase

    const flowOutput = await describeFlow(instanceId, contactFlowId);

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(flowOutput),
    };

    return response; // Directly return the response instead of using a callback
};
