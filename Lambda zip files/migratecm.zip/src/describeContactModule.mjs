import corSetting from './common/constants.mjs';
import { describeModule } from './common/describeModule.mjs';

const BucketName = process.env.BucketName;

export const describeContactModule = async (event) => {
    console.log(JSON.stringify({ event }));

    if (event.httpMethod !== 'GET') {
        throw new Error(`GET method only accepts GET method, you tried: ${event.httpMethod} method.`);
    }

    const body = JSON.parse(event.body);
    const instanceId = body.instanceId; // Corrected spelling
    const contactFlowModuleId = body.ContactFlowModuleId; // Use camelCase

    const flowOutput = await describeModule(instanceId, contactFlowModuleId);

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(flowOutput),
    };

    return response; // Directly return the response instead of using a callback
};
