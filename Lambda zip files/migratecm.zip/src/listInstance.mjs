import corSetting from './common/constants.mjs';
import { listInstanceFlow } from './common/listInstanceFlow.mjs';

const BucketName = process.env.BucketName;

export const listInstance = async (event) => {
    console.log(JSON.stringify({ event }));

    if (event.httpMethod !== 'GET') {
        throw new Error(`GET method only accepts GET method, you tried: ${event.httpMethod} method.`);
    }

    let instanceList = [];
    let nextToken = ""; // Initialize nextToken for pagination
    let flowOutput;

    do {
        flowOutput = nextToken
            ? await listInstanceFlow(nextToken)
            : await listInstanceFlow();
        
        instanceList = [...instanceList, ...flowOutput.InstanceSummaryList]; // Append new instances to the list
        nextToken = flowOutput.NextToken; // Update nextToken for the next iteration
    } while (nextToken);

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(instanceList),
    };

    return response; // Directly return the response instead of using a callback
};
