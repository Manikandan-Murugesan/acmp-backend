import corSetting from './common/constants.mjs';
import contactFlowEventLogHelper from './common/contactFlowEventLogHelper.mjs';
import cognitoTokenParser from './common/cognitoTokenParser.mjs';
import { createContactFlow, updateContactFlow } from './common/createContactFlow.mjs';
import { describeFlow } from './common/describeFlow.mjs';
import { getItemFromDDB } from './common/getItemFromDDB.mjs';
import { scanItemFromDDB } from './common/scanItemFromDDB.mjs';

const updateContactFlowLogic = async (flowContent, parsedBody) => {
    const updatedActions = flowContent.Actions;
    console.log('No. of Actions Block : ', updatedActions.length);

    for (const action of updatedActions) {
        console.log(action);
        try {
            switch (action['Type']) {
                case 'MessageParticipant':
                case 'GetParticipantInput':
                    await updatePromptId(action, parsedBody);
                    break;
                case 'InvokeLambdaFunction':
                    updateLambdaFunctionARN(action, parsedBody);
                    break;
                case 'UpdateContactTargetQueue':
                    await updateQueueId(action, parsedBody);
                    break;
                case 'ConnectParticipantWithLexBot':
                    console.log("need to update the lex ARN");
                    break;
                case 'UpdateContactEventHooks':
                    await updateEventHooks(action, parsedBody);
                    break;
                case 'InvokeFlowModule':
                    await updateModuleId(action, parsedBody);
                    break;
                default:
                    console.log(`The action block ${action['Type']} requires no change`);
            }
        } catch (error) {
            console.log("Error updating action:", error);
            return { error: error.message };
        }
    }

    return flowContent; // Return updated flow content
};

const updatePromptId = async (action, parsedBody) => {
    if (action.Parameters.PromptId) {
        const srcPromptId = action.Parameters.PromptId.split('/').pop();
        const getSrcPromptDet = await getItemFromDDB(process.env[`instance_${parsedBody.srcInstanceId.replaceAll("-", "")}`], srcPromptId);
        const getSrcPromptName = getSrcPromptDet.Item.Name;

        const filterExpression = `#PN = :PN`;
        const expressionAttributeNames = { '#PN': 'Name' };
        const expressionAttributeValues = { ':PN': getSrcPromptName };

        const destPromptDet = await scanItemFromDDB(process.env[`instance_${parsedBody.destInstanceId.replaceAll("-", "")}`], filterExpression, expressionAttributeNames, expressionAttributeValues);

        if (destPromptDet.Count === 1) {
            const destPromptArn = destPromptDet.Items[0].Arn;
            action.Parameters.PromptId = destPromptArn;
        } else {
            throw new Error(`The Prompt "${getSrcPromptName}" is ${destPromptDet.Count > 1 ? 'configured more than once' : 'missing'} in ${parsedBody.destInstanceId}`);
        }
    }
};

const updateLambdaFunctionARN = (action, parsedBody) => {
    const srcLambdaFunctionARN = action.Parameters.LambdaFunctionARN;
    action.Parameters.LambdaFunctionARN = srcLambdaFunctionARN
        .replace(parsedBody.srcRegion, parsedBody.destRegion)
        .replace(parsedBody.srcAccountId, parsedBody.destAccountId);
};

const updateQueueId = async (action, parsedBody) => {
    const srcQueueId = action.Parameters.QueueId.split('/').pop();
    const getSrcQueueDet = await getItemFromDDB(process.env[`instance_${parsedBody.srcInstanceId.replaceAll("-", "")}`], srcQueueId);
    const getSrcQueueName = getSrcQueueDet.Item.Name;

    const filterExpression = `#QT = :QT AND #QN = :QN`;
    const expressionAttributeNames = { '#QT': 'QueueType', '#QN': 'Name' };
    const expressionAttributeValues = { ':QT': 'STANDARD', ':QN': getSrcQueueName };

    const destQueueDet = await scanItemFromDDB(process.env[`instance_${parsedBody.destInstanceId.replaceAll("-", "")}`], filterExpression, expressionAttributeNames, expressionAttributeValues);

    if (destQueueDet.Count === 1) {
        const destQueueArn = destQueueDet.Items[0].Arn;
        action.Parameters.QueueId = destQueueArn;
    } else {
        throw new Error(`The Queue "${getSrcQueueName}" is ${destQueueDet.Count > 1 ? 'configured more than once' : 'missing'} in ${parsedBody.destInstanceId}`);
    }
};

const updateEventHooks = async (action, parsedBody) => {
    const flowType = Object.keys(action.Parameters.EventHooks)[0];
    const allowedFlowTypes = ['AgentWhisper', 'AgentHold', 'CustomerHold', 'CustomerWhisper', 'CustomerQueue', 'CustomerRemaining'];

    if (allowedFlowTypes.includes(flowType)) {
        const srcFlowId = action.Parameters.EventHooks[flowType].split('/').pop();
        const getSrcFlowDet = await getItemFromDDB(process.env[`instance_${parsedBody.srcInstanceId.replaceAll("-", "")}`], srcFlowId);
        const getSrcFlowName = getSrcFlowDet.Item.Name;

        const filterExpression = `#FN = :FN`;
        const expressionAttributeNames = { '#FN': 'Name' };
        const expressionAttributeValues = { ':FN': getSrcFlowName };

        const destFlowDet = await scanItemFromDDB(process.env[`instance_${parsedBody.destInstanceId.replaceAll("-", "")}`], filterExpression, expressionAttributeNames, expressionAttributeValues);

        if (destFlowDet.Count === 1) {
            const destFlowArn = destFlowDet.Items[0].Arn;
            action.Parameters.EventHooks[flowType] = destFlowArn;
        } else {
            throw new Error(`The Flow "${getSrcFlowName}" is ${destFlowDet.Count > 1 ? 'configured more than once' : 'missing'} in ${parsedBody.destInstanceId}`);
        }
    }
};

const updateModuleId = async (action, parsedBody) => {
    const srcModuleId = action.Parameters.FlowModuleId;
    const getSrcModuleDet = await getItemFromDDB(process.env[`instance_${parsedBody.srcInstanceId.replaceAll("-", "")}`], srcModuleId);
    const getSrcModuleName = getSrcModuleDet.Item.Name;

    const filterExpression = `#MN = :MN`;
    const expressionAttributeNames = { '#MN': 'Name' };
    const expressionAttributeValues = { ':MN': getSrcModuleName };

    const destModuleDet = await scanItemFromDDB(process.env[`instance_${parsedBody.destInstanceId.replaceAll("-", "")}`], filterExpression, expressionAttributeNames, expressionAttributeValues);

    if (destModuleDet.Count === 1) {
        const destModuleArn = destModuleDet.Items[0].Arn;
        action.Parameters.FlowModuleId = destModuleArn;
    } else {
        throw new Error(`The Module "${getSrcModuleName}" is ${destModuleDet.Count > 1 ? 'configured more than once' : 'missing'} in ${parsedBody.destInstanceId}`);
    }
};

export const migrateContactFlow = async (event, context) => {
    const response = { headers: corSetting };
    console.log(JSON.stringify({ event }));

    if (event.httpMethod !== 'POST') {
        throw new Error(`migrateContactFlow only accepts POST method, you tried: ${event.httpMethod} method.`);
    }

    const parsedBody = JSON.parse(event.body);
    console.log(JSON.stringify({ parsedBody }));

    const srcFlowOutput = await describeFlow(parsedBody.srcInstanceId, parsedBody.srcFlowId);
    console.log(JSON.stringify({ srcFlowOutput }));

    const srcFlowContent = JSON.parse(srcFlowOutput.ContactFlow.Content);
    const updatedContent = await updateContactFlowLogic(srcFlowContent, parsedBody);

    if (updatedContent.error) {
        response.statusCode = 400; // Change status code for an error
        response.body = updatedContent.error;
    } else {
        response.statusCode = 200;
        srcFlowOutput.ContactFlow.Content = JSON.stringify(updatedContent);

        console.log("output-->", JSON.stringify({ srcFlowOutput }));
        const srcCallFlowName = srcFlowOutput.ContactFlow.Name;

        const filterExpression = `#FN = :FN`;
        const expressionAttributeNames = { '#FN': 'Name' };
        const expressionAttributeValues = { ':FN': srcCallFlowName };

        const destCallFlowDet = await scanItemFromDDB(process.env[`instance_${parsedBody.destInstanceId.replaceAll("-", "")}`], filterExpression, expressionAttributeNames, expressionAttributeValues);

        try {
            if (destCallFlowDet.Count === 0) {
                const input = {
                    InstanceId: parsedBody.destInstanceId,
                    Name: srcFlowOutput.ContactFlow.Name,
                    Type: parsedBody.srcFlowType,
                    Content: srcFlowOutput.ContactFlow.Content,
                    Tags: {
                        "CREATOR": "CN-CONNECT-MNGR",
                    },
                };
                console.log("Input--", input);
                const result = await createContactFlow(input);
                response.body = JSON.stringify(result);
            } else {
                const input = {
                    InstanceId: parsedBody.destInstanceId,
                    ContactFlowId: destCallFlowDet.Items[0].Id,
                    Content: srcFlowOutput.ContactFlow.Content
                };
                console.log("Input--", input);
                const result = await updateContactFlow(input);
                response.body = JSON.stringify(result);
            }
        } catch (e) {
            response.statusCode = 500; // Change status code for a server error
            response.body = JSON.stringify(e.problems);
        }

        const username = cognitoTokenParser.getUserId(event.headers.Authorization);
        console.info('username:', username);
        const requestId = `${username}_${Date.now()}`;
        console.log("Request ID", requestId);
        await contactFlowEventLogHelper.saveData(requestId, '', username, srcFlowOutput.ContactFlow.Name, '', "MIGRATE", parsedBody.srcInstanceId, parsedBody.destInstanceId);
    }
    console.log(response);
    return response;
};
