import { ConnectClient, CreateContactFlowModuleCommand } from "@aws-sdk/client-connect"; // ES Modules import
import corSetting from './common/constants';
import { contactFlowEventLogHelper } from './common/contactFlowEventLogHelper.js';

const BucketName = process.env.BucketName;

export const updateArn = async (event, context) => {
    console.log(JSON.stringify({ event }));

    // Ensure the method is PUT
    if (event.httpMethod !== 'PUT') {
        return {
            statusCode: 405, // Method Not Allowed
            headers: corSetting,
            body: JSON.stringify({ error: `PUT only accepts PUT method, you tried: ${event.httpMethod} method.` })
        };
    }

    const client = new ConnectClient(config);
    const body = JSON.parse(event.body);
    const { instanceId, cName: name, cfType } = body;

    // Handle file content
    let fileContent;
    if (event.isBase64Encoded) {
        fileContent = Buffer.from(event.body, 'base64').toString('utf-8').split('\r\n')[4].trim();
    } else {
        fileContent = event.body.split('\r\n')[4].trim();
    }

    // Prepare input for CreateContactFlowModuleCommand
    const input = {
        InstanceId: instanceId,
        Name: name,
        Content: fileContent
    };

    try {
        const command = new CreateContactFlowModuleCommand(input);
        const flowOutput = await client.send(command);

        // Log the upload action
        // const username = /* Extract username from the context or event */;
        const requestId = `${username}_${Date.now()}`;
        await contactFlowEventLogHelper.saveData(requestId, username, 'UPLOAD');

        // Prepare and return the response
        return {
            statusCode: 200,
            headers: corSetting,
            body: JSON.stringify(flowOutput)
        };
    } catch (error) {
        console.error("Error creating contact flow module:", error);
        return {
            statusCode: 500, // Internal Server Error
            headers: corSetting,
            body: JSON.stringify({ error: 'Failed to create contact flow module.', details: error.message })
        };
    }
};
