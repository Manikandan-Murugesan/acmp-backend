import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const tableName = process.env.EventTable;

export const s3PromptEventLogHelper = {
    async saveData(requestId, bucketName, key, userId, operation) {
        const inputTextToDB = {
            requestId,
            bucketName,
            key,
            userId,
            operation,
            timestampDate: Date.now()
        };

        const paramsIns = {
            TableName: tableName,
            Item: inputTextToDB
        };

        console.log('s3PromptEventLogHelper saveData paramsIns', paramsIns);
        const response = await docClient.put(paramsIns).promise();
        console.log('s3PromptEventLogHelper saveData response', response);
        return response;
    },

    async gets3PromptEventLog(contactId) {
        const params = {
            TableName: tableName,
            KeyConditionExpression: "#contactId = :contactId",
            ExpressionAttributeNames: {
                "#contactId": "contactId"
            },
            ExpressionAttributeValues: {
                ":contactId": contactId
            }
        };

        const output = await docClient.query(params).promise();
        return output;
    },

    async scans3PromptEventLog() {
        const params = {
            TableName: tableName,
        };

        const scanResults = [];
        const command = new ScanCommand(params);
        const response = await client.send(command);
        // const items = await docClient.scan(params).promise();
        response.Items.forEach(item => scanResults.push(item));

        console.info('scanResults:', scanResults);
        return scanResults;
    }
};
