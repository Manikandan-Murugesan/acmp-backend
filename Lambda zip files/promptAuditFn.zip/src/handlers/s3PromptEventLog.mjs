import { corSetting } from './common/constants.mjs';
import { s3PromptEventLogHelper } from './common/s3PromptEventLogHelper.mjs';

export const getS3PromptEventLog = async (event) => {
    console.info('received:', event);

    const result = await s3PromptEventLogHelper.scans3PromptEventLog();

    return {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(result)
    };
};
