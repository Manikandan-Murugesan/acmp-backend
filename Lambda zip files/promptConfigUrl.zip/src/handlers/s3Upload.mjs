import { uploadObject } from './common/uploadObject.mjs';
import { corSetting } from './common/constants.mjs';
import { s3PromptEventLogHelper } from './common/s3PromptEventLogHelper.mjs';
import { getUserId } from './common/cognitoTokenParser.mjs';

const BucketName = process.env.BucketName;

export const uploadFile = async (event) => {
    console.info('event:', event);

    if (event.httpMethod !== 'POST') {
        throw new Error(`postMethod only accepts POST method, you tried: ${event.httpMethod} method.`);
    }

    console.log(event.isBase64Encoded);
    const username = getUserId(event.headers.Authorization);

    const s3ObjectPath = event.headers.s3ObjectPath;
    const contentType = event.body.contentType;
    console.log(s3ObjectPath, contentType);

    const fileContent = event.isBase64Encoded ? Buffer.from(event.body, 'base64') : event.body;

    let output = false;

    if (s3ObjectPath) {
        output = await uploadObject.uploadFile(BucketName, s3ObjectPath, fileContent);
        if (output) {
            const requestId = `${username}_${s3ObjectPath}_${Date.now()}`;
            await s3PromptEventLogHelper.saveData(requestId, BucketName, s3ObjectPath, username, 'UPLOAD');
        }
    }

    return {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(output)
    };
};
