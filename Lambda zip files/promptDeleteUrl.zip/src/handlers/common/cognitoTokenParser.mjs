export function getUserId(token) {
    let usernameValue = '';
    try {
        const segments = token.split('.');
        if (segments.length !== 3) {
            throw new Error('Invalid token structure');
        }
        const payloadSeg = segments[1];
        const payload = JSON.parse(base64UrlDecode(payloadSeg));
        usernameValue = payload['cognito:username'];
    } catch (e) {
        console.error(e);
    }
    return usernameValue;
}

function base64UrlDecode(str) {
    // Ensure padding is correct for base64 decoding
    const base64 = str.replace(/-/g, '+').replace(/_/g, '/');
    return Buffer.from(base64, 'base64').toString('utf8');
}
