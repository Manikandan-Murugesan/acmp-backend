import { S3Client, ListObjectsCommand } from "@aws-sdk/client-s3";

const region = process.env.Region;
const client = new S3Client({ region });

export const listObjects = {
    async getBucketObjects(bucketName, prefix) {
        try {
            const listObjectsCommandRequest = {
                Bucket: bucketName,
                ...(prefix && { Prefix: prefix }) // Add Prefix only if it is provided
            };

            const command = new ListObjectsCommand(listObjectsCommandRequest);
            const response = await client.send(command);
            console.log(response);

            return response;
        } catch (error) {
            console.error(error);
            return null; // Return null or handle as necessary in case of an error
        }
    }
};
