import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";

const region = process.env.Region;
const client = new S3Client({ region });

export const s3PresignedUrl = {
    async getPresignedUrl(bucketName, objectKey) {
        try {
            const getObjectParams = {
                Bucket: bucketName,
                Key: objectKey
            };

            const command = new GetObjectCommand(getObjectParams);
            const url = await getSignedUrl(client, command, { expiresIn: 3600 });

            console.log(url);
            return url;
        } catch (error) {
            console.error(error);
            return null; // Ensure a consistent return type
        }
    }
};
