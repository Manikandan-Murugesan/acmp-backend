import { corSetting } from './common/constants.mjs';

const BucketName = process.env.BucketName;
const CognitoPool = process.env.CognitoPool;
const Region = process.env.Region;
const UserPool = process.env.UserPool;
const PromptIdentityPool = process.env.PromptIdentityPool;

export const getConfig = async (event, context, callback) => {
    console.info('event:', event);
    
    const output = {
        BucketName,
        CognitoPool,
        Region,
        UserPool,
        PromptIdentityPool
    };

    console.info('output:', output);

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(output)
    };
    
    callback(null, response);
};
