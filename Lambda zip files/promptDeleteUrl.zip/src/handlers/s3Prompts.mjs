import { listObjects } from './common/listObjects.mjs';
import { corSetting } from './common/constants.mjs';

const BucketName = process.env.BucketName;

export const getPrompts = async (event, context, callback) => {
    console.info('received:', event);

    const s3Output = await listObjects.getBucketObjects(BucketName, event.headers.prefix);
    const promptList = [];
    let count = 1;

    if (s3Output && s3Output.Contents) {
        s3Output.Contents.forEach(content => {
            if (content) {
                const prompt = {
                    id: count,
                    size: content.Size,
                    key: content.Key
                };
                promptList.push(prompt);
                count++;
            }
        });
    }

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(promptList)
    };

    callback(null, response);
};
