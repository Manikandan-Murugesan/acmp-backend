import { CognitoIdentityProviderClient, AdminSetUserPasswordCommand, AdminCreateUserCommand } from "@aws-sdk/client-cognito-identity-provider";

const adminCreateUser = {
  async create(region, userPoolId, email, passwordGenerated) {
    const cognitoIdentityProviderClient = new CognitoIdentityProviderClient({ region });

    const params = {
      UserPoolId: userPoolId,
      Username: email,
      DesiredDeliveryMediums: ["EMAIL"],
      ForceAliasCreation: false,
      UserAttributes: [
        { Name: 'email', Value: email },
        { Name: 'email_verified', Value: "true" }
      ],
      TemporaryPassword: passwordGenerated
    };

    const command = new AdminCreateUserCommand(params);
    const response = await cognitoIdentityProviderClient.send(command);

    console.log(response);
    return response;
  },

  async setUserPassword(region, userPoolId, email, password) {
    const cognitoIdentityProviderClient = new CognitoIdentityProviderClient({ region });

    const params = {
      UserPoolId: userPoolId,
      Username: email,
      Password: password,
      Permanent: true
    };

    const command = new AdminSetUserPasswordCommand(params);
    const response = await cognitoIdentityProviderClient.send(command);

    console.log(response);
    return response;
  }
};

export default adminCreateUser;
