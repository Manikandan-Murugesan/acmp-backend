export function getUserId(token) {
  let usernameValue = '';
  
  try {
    const segments = token.split('.');
    
    if (segments.length !== 3) {
      throw new Error('Invalid token structure');
    }
    
    const payloadSeg = segments[1];
    const payload = JSON.parse(_base64urlDecode(payloadSeg));
    
    usernameValue = payload['cognito:username'];
    
  } catch (error) {
    console.log(error);
  }
  
  return usernameValue;
}

function _base64urlDecode(str) {
  return Buffer.from(str, 'base64').toString('utf-8');
}
