export const corSetting = {
    'Access-Control-Allow-Origin': '*',  // Allows all domains to access the resource.
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',  // Specifies the allowed headers in the request.
    'Access-Control-Allow-Credentials': true,  // Allows the client to send credentials (e.g., cookies, authorization headers) with requests.
    'Content-Type': 'application/json',  // Specifies the content type as JSON.
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'  // Lists the allowed HTTP methods for cross-origin requests.
}
