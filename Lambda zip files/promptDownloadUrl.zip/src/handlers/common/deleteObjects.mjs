const region = process.env.Region;

import { S3Client, DeleteObjectCommand } from "@aws-sdk/client-s3";
const client = new S3Client({ region });

export const deleteObjects = {
    async deleteObjects(bucketName, key) {
        let response = null;
        let output = false;
        
        try {
            const deleteObjectCommandInput = {
                Bucket: bucketName,
                Key: key
            };

            const command = new DeleteObjectCommand(deleteObjectCommandInput);
            response = await client.send(command);
            console.log(response);

            output = true;
        } catch (error) {
            console.error(error);
        }
        
        return output;
    }
};
