const region = process.env.Region;

import { S3Client, ListObjectsCommand } from "@aws-sdk/client-s3";
const client = new S3Client({ region });

export const listObjects = {
    async getBucketObjects(bucketName, prefix) {
        let response = null;
        
        try {
            const ListObjectsCommandRequest = {
                Bucket: bucketName,
                ...(prefix && { Prefix: prefix }) // Include Prefix only if it's provided
            };

            const command = new ListObjectsCommand(ListObjectsCommandRequest);
            response = await client.send(command);
            console.log(response);
        } catch (error) {
            console.error(error);
        }

        return response;
    }
};
