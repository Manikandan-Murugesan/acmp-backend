import { s3PresignedUrl } from "./common/s3PresignedUrl.mjs";
import { corSetting } from "./common/constants.mjs";
import { getUserId } from "./common/cognitoTokenParser.mjs";

const BucketName = process.env.BucketName;

export const getPresignedUrl = async (event, context) => {
  console.info('event:', event);

  if (event.httpMethod !== 'POST') {
    throw new Error(`postMethod only accepts POST method, you tried: ${event.httpMethod} method.`);
  }

  const body = JSON.parse(event.body);
  const username = getUserId(event.headers.Authorization);

  const s3ObjectPath = body.s3ObjectPath;

  let presignedUrl = '';
  console.log("Presigned url -->", presignedUrl);

  console.info('post body :', username, s3ObjectPath);

  if (username && s3ObjectPath) {
    presignedUrl = await s3PresignedUrl.getPresignedUrl(BucketName, s3ObjectPath);
  }

  const response = {
    statusCode: 200,
    headers: corSetting,
    body: JSON.stringify(presignedUrl)
  };

  return response;
};
