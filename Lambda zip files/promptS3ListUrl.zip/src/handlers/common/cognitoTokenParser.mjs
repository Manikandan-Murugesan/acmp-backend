function getUserId(token) {
  let usernameValue = '';
  
  try {
    const segments = token.split('.');
    
    if (segments.length !== 3) {
      throw new Error('Not enough or too many segments');
    }
    
    const payloadSeg = segments[1];
    const payload = JSON.parse(base64urlDecode(payloadSeg));
    
    usernameValue = payload['cognito:username'];
  } catch (e) {
    console.error(e);
  }
  
  return usernameValue;
}

function base64urlDecode(str) {
  return Buffer.from(str, 'base64');
}

export { getUserId };
