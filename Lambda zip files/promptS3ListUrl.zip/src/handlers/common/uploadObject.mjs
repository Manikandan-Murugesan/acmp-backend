import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

const region = process.env.Region;
const client = new S3Client({ region });

const uploadObject = {
  async uploadFile(bucketName, key, fileBody) {
    let response = null;
    let output = false;

    try {
      const putObjectCommand = {
        Bucket: bucketName,
        Key: key,
        Body: fileBody
      };

      const command = new PutObjectCommand(putObjectCommand);
      response = await client.send(command);
      console.log(response);

      output = true;
    } catch (error) {
      console.error(error);
    }

    return output;
  }
};

export default uploadObject;
