import s3PresignedUrl from './common/s3PresignedUrl.js';
import corSetting from './common/constants';
import cognitoTokenParser from './common/cognitoTokenParser.js';

const BucketName = process.env.BucketName;

export const getPresignedUrl = async (event, context, callback) => {
    console.info('event:', event);

    if (event.httpMethod !== 'POST') {
        throw new Error(`postMethod only accepts POST method, you tried: ${event.httpMethod} method.`);
    }

    const body = JSON.parse(event.body);
    const username = cognitoTokenParser.getUserId(event.headers.Authorization);
    const s3ObjectPath = body.s3ObjectPath;

    let presignedUrl = '';

    console.info('post body:', username, s3ObjectPath);

    if (username && s3ObjectPath) {
        presignedUrl = await s3PresignedUrl.getPresignedUrl(BucketName, s3ObjectPath);
    }

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(presignedUrl)
    };
    callback(null, response);
};
