import deleteObjects from './common/deleteObjects.js';
import corSetting from './common/constants';
import s3PromptEventLogHelper from './common/s3PromptEventLogHelper.js';
import cognitoTokenParser from './common/cognitoTokenParser.js';

const BucketName = process.env.BucketName;

export const deletePrompt = async (event, context, callback) => {
    console.info('event:', event);

    if (event.httpMethod !== 'POST') {
        throw new Error(`deletePrompt only accepts POST method, you tried: ${event.httpMethod} method.`);
    }

    const body = JSON.parse(event.body);
    const username = cognitoTokenParser.getUserId(event.headers.Authorization);
    console.info('username:', username);

    const s3ObjectPath = body.s3ObjectPath;
    
    console.info('post body:', s3ObjectPath);

    const s3Output = await deleteObjects.deleteObjects(BucketName, s3ObjectPath);

    if (s3Output) {
        const requestId = `${username}_${s3ObjectPath}_${Date.now()}`;
        await s3PromptEventLogHelper.saveData(requestId, BucketName, s3ObjectPath, username, 'DELETE');
    }

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(s3Output)
    };

    callback(null, response);
};
