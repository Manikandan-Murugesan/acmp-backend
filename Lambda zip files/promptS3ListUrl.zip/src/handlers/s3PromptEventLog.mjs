import corSetting from './common/constants';
import s3PromptEventLogHelper from './common/s3PromptEventLogHelper.js';

export const getS3PromptEventLog = async (event, context, callback) => {
    console.info('received:', event);
    
    const result = await s3PromptEventLogHelper.scans3PromptEventLog();

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(result)
    };

    callback(null, response);
};
