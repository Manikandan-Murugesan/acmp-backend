import { listObjects } from './common/listObjects.mjs';
import { corSetting } from './common/constants.mjs';

const BucketName = process.env.BucketName;

function formatFileSize(bytes, decimalPoint = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1000;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(decimalPoint))} ${sizes[i]}`;
}

export const getPrompts = async (event, context, callback) => {
    const output = {};

    // All log statements are written to CloudWatch
    console.info('received:', event);
    
    const s3Output = await listObjects.getBucketObjects(BucketName, event.headers.prefix);
    const promptList = [];
    let count = 1;

    if (s3Output && s3Output.Contents) {
        s3Output.Contents.forEach(content => {
            if (content) {
                console.log('content', content);
                const prompt = {
                    id: count,
                    size: formatFileSize(content.Size),
                    key: content.Key
                };
                promptList.push(prompt);
                count++;
            }
        });
    }

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(promptList)
    };

    callback(null, response);
};
