import uploadObject from './common/uploadObject.js';
import corSetting from './common/constants';
import s3PromptEventLogHelper from './common/s3PromptEventLogHelper.js';
import cognitoTokenParser from './common/cognitoTokenParser.js';

const BucketName = process.env.BucketName;

export const uploadFile = async (event, context, callback) => {
    console.info('event:', event);
    let output = false;

    if (event.httpMethod !== 'POST') {
        throw new Error(`uploadFile only accepts POST method, you tried: ${event.httpMethod} method.`);
    }

    console.log(event.isBase64Encoded);
    const username = cognitoTokenParser.getUserId(event.headers.Authorization);
    const s3ObjectPath = event.headers.s3ObjectPath;
    const contentType = event.body.contentType;
    console.log(s3ObjectPath, contentType);

    const fileContent = event.isBase64Encoded ? Buffer.from(event.body, 'base64') : event.body;

    if (s3ObjectPath) {
        output = await uploadObject.uploadFile(BucketName, s3ObjectPath, fileContent);
        
        if (output) {
            const requestId = `${username}_${s3ObjectPath}_${Date.now()}`;
            await s3PromptEventLogHelper.saveData(requestId, BucketName, s3ObjectPath, username, 'UPLOAD');
        }
    } else {
        // If not getting s3ObjectPath
        output = false;        
    }

    const response = {
        statusCode: 200,
        headers: corSetting,
        body: JSON.stringify(output)
    };

    callback(null, response);
};
