import response from 'cfn-response';
import cognitoAdminCreateUser from './common/cognitoAdminCreateUser';

export const handler = async (event, context) => {
  const result = {
    responseStatus: "FAILED",
    responseData: { Data: "Never updated" },
  };

  console.info("received:", JSON.stringify(event));

  try {
    const { UserPool: userPool, Region: region, email } = event.ResourceProperties;
    const passwordGenerated = generatePassword();

    await cognitoAdminCreateUser.create(region, userPool, email, passwordGenerated);
    await cognitoAdminCreateUser.setUserPassword(region, userPool, email, passwordGenerated);

    result.responseStatus = "SUCCESS";
    result.responseData["Data"] = "Successfully uploaded files";
  } catch (error) {
    console.error(JSON.stringify(error, null, 4));
    result.responseStatus = "FAILED";
    result.responseData["Data"] = "Failed to process event";
  } finally {
    return await responsePromise(event, context, result.responseStatus, result.responseData, 'mainstack');
  }
};

const responsePromise = (event, context, responseStatus, responseData, physicalResourceId) => {
  return new Promise((resolve) => {
    response.send(event, context, responseStatus, responseData, physicalResourceId);
    resolve();
  });
};

const generatePassword = () => {
  const randPassword1 = Array(4).fill("ABCDEFGHIJKLMNOPQRSTUVWXYZ").map(x => x[Math.floor(Math.random() * x.length)]).join('');
  const randPassword2 = Array(4).fill("abcdefghijklmnopqrstuvwxyz").map(x => x[Math.floor(Math.random() * x.length)]).join('');
  const randPassword3 = Array(4).fill("0123456789").map(x => x[Math.floor(Math.random() * x.length)]).join('');
  return `${randPassword1}${randPassword2}@${randPassword3}`;
};
