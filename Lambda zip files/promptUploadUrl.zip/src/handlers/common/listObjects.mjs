import { S3Client, ListObjectsCommand } from "@aws-sdk/client-s3";

const region = process.env.Region;
const client = new S3Client({ region });

export const listObjects = {
    async getBucketObjects(bucketName, prefix) {
        let response = null;
        try {
            const listObjectsCommandRequest = {
                Bucket: bucketName,
                ...(prefix && { Prefix: prefix }) // Conditionally add Prefix if it exists
            };

            const command = new ListObjectsCommand(listObjectsCommandRequest);
            response = await client.send(command);
            console.log(response);
        } catch (error) {
            console.error(error);
        }
        return response;
    }
};
