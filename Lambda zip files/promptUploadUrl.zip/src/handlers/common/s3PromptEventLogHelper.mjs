import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(client);
const tableName = process.env.EventTable;

export const s3PromptEventLogHelper = {
    async saveData(requestId, bucketName, key, userId, operation) {
        const paramsIns = {
            TableName: tableName,
            Item: {
                requestId,
                bucketName,
                key,
                userId,
                operation,
                timestampDate: Date.now()
            }
        };

        try {
            const command = new PutCommand(paramsIns);
            const response = await ddbDocClient.send(command);
            console.log('s3PromptEventLogHelper saveData response', response);
            return response;
        } catch (error) {
            console.error('Error saving data:', error);
            throw error;
        }
    },

    async gets3PromptEventLog(contactId) {
        const params = {
            TableName: tableName,
            KeyConditionExpression: "#contactId = :contactId",
            ExpressionAttributeNames: {
                "#contactId": "contactId"
            },
            ExpressionAttributeValues: {
                ":contactId": contactId
            }
        };

        try {
            const output = await ddbDocClient.query(params);
            return output;
        } catch (error) {
            console.error('Error getting data:', error);
            throw error;
        }
    },

    async scans3PromptEventLog() {
        const params = {
            TableName: tableName
        };

        try {
            const { Items } = await ddbDocClient.scan(params);
            console.info('scanResults:', Items);
            return Items;
        } catch (error) {
            console.error('Error scanning data:', error);
            throw error;
        }
    }
};
