import { S3 } from '@aws-sdk/client-s3';
import { send } from 'cfn-response';

const s3 = new S3();
const sourceBucket = 'aws-contact-center-blog';
const sourcePrefix = 'amazon-s3-prompt-ui';
const sourceObjectArray = [
  'index.zip',
  's3PromptUi.zip'
];

export const handler = async (event, context) => {
  const result = {
    responseStatus: 'FAILED',
    responseData: { Data: 'Never updated' }
  };

  console.info(`Received event with type ${event.RequestType}`);

  try {
    if (event.RequestType === 'Create' || event.RequestType === 'Update') {
      await Promise.all(
        sourceObjectArray.map(async (object) => {
          const copyObjectParams = {
            Bucket: event.ResourceProperties.SolutionSourceBucket,
            Key: object,
            CopySource: `${sourceBucket}/${sourcePrefix}/${object}`
          };
          const s3Result = await s3.copyObject(copyObjectParams);
          console.info(`Finished uploading File with result ${JSON.stringify(s3Result, null, 4)}`);
        })
      );

      result.responseStatus = 'SUCCESS';
      result.responseData.Data = 'Successfully uploaded files';
    } else if (event.RequestType === 'Delete') {
      result.responseStatus = 'SUCCESS';
      result.responseData.Data = 'Successfully deleted files';
    }
  } catch (error) {
    console.error(JSON.stringify(error, null, 4));
    result.responseStatus = 'FAILED';
    result.responseData.Data = 'Failed to process event';
  } finally {
    return responsePromise(event, context, result.responseStatus, result.responseData, 'mainstack');
  }
};

const responsePromise = (event, context, responseStatus, responseData, physicalResourceId) => {
  return new Promise((resolve) => {
    send(event, context, responseStatus, responseData, physicalResourceId);
    resolve();
  });
};
